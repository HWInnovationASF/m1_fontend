# import paho.mqtt.client as mqtt
# import time

# # # The callback for when the client receives a CONNACK response from the server.
# # def on_connect(client, userdata, flags, reason_code, properties):
# #     print(f"Connected with result code {reason_code}")
# #     # Subscribing in on_connect() means that if we lose the connection and
# #     # reconnect then subscriptions will be renewed.
# #     client.subscribe("meow/#")

# # # The callback for when a PUBLISH message is received from the server.
# # def on_message(client, userdata, msg):
# #     print(msg.topic+" "+str(msg.payload))

# mqttc = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
# # mqttc.on_connect = on_connect
# # mqttc.on_message = on_message

# mqttc.connect("mqtt.mdbiot.com", 1883, 60)

# # Blocking call that processes network traffic, dispatches callbacks and
# # handles reconnecting.
# # Other loop*() functions are available that give a threaded interface and a
# # manual interface.
# # mqttc.loop_forever()


# # mqttc.loop_start()
# mqttc.publish("meow/M117300806401466", "test_check_mqtt123")

# # while True:
# #     mqttc.publish("meow/M117300806401466", "test_check_mqtt")
# #     time.sleep(1)

from ast import Global
import requests
import json
import time
from datetime import datetime
import threading #muti core  
import os
import numpy as np #convert Hex float
from zipfile import ZipFile
import zipfile
import ssl
import websocket
import ftplib
import rel

from base64 import b64encode, b64decode 
from Crypto.Cipher import AES #pip install pycryptodome
from Crypto.Util.Padding import pad,unpad
import paho.mqtt.client as mqtt


requests.packages.urllib3.disable_warnings(requests.packages.urllib3.exceptions.InsecureRequestWarning)
g_cne = "cVpWUUl6ZGR1QUUxRy9XL1lWYWpiN1lPSUIzZE9YUmRHdTJtT1ZqK2c5bz0="
ts_cmd = 0
status_vpn = 0

def read_file(pathFile):
    data_cml = ""
    if os.path.exists(pathFile):
        f = open(pathFile, "r")
        data_cml = f.read()
        # print(data_cml)
        f.close()
    return data_cml

def writefile(data,filename,mode):
    # rrr = json.dumps(data)
    rrr = data
    open(str(filename), mode).write(rrr)
    f = open (str(filename))
    # print ("Update!!",filename,"Data=")
    f.close()

def is_json(wsJson):
    try:
        json.loads(wsJson)
    except ValueError as e:
        return False
    return True

def denc_ssl(data, key, iv=""):
    data_byte = b64decode(data.encode('ascii'))
    data_byte = data_byte.decode('ascii')
    data_byte = b64decode(data_byte.encode('utf-8'))
    key_byte = key.encode('utf-8')
    key_byte = key_byte.ljust(16, "\0".encode('utf-8'))
    if len(key_byte) > 16:
        key_byte = key_byte[:len(key_byte)]
    iv_byte = iv.encode('utf-8')
    iv_byte = iv_byte.ljust(16, "\0".encode('utf-8'))
    if len(iv_byte) > 16:
        key_byte = key_byte[:len(iv_byte)]
    cryptor = AES.new(key_byte, AES.MODE_CBC, iv_byte)
    c_text = cryptor.decrypt(data_byte)
    # PKCS#5
    pad_len = ord(c_text.decode('utf-8')[-1])
    clear_text = c_text.decode('utf-8')[:-pad_len]
    return b64decode(clear_text.encode('utf-8')).decode('utf-8')

def enc_ssl(clear_text,key,iv):
    # encrypt
    clear_text2 = b64encode(clear_text.encode('ascii'))
    # print(clear_text2.decode('utf-8'))
    data_aaa = clear_text2.decode('ascii')

    data_aaa_en = data_aaa.encode('utf-8')

    key_byte = key.encode('utf-8').ljust(16, "\0".encode('utf-8'))
    iv_byte = iv.encode('utf-8').ljust(16, "\0".encode('utf-8'))

    cryptor = AES.new(key_byte, AES.MODE_CBC, iv_byte)
    enc_data = cryptor.encrypt(pad(data_aaa_en,block_size=16)) #8
    return b64encode(enc_data).decode('utf-8')

# ////////////////////// Variable
key             = "inno2024"
iv              = ""
# main_txt = read_file('mcf.json')
# main_txt = denc_ssl(main_txt, key, iv="")
path_def = "/var/www/html/data/mcf_default.json"
main_txt = read_file(path_def)
# main_txt = denc_ssl(read_file('mcf.json'),key,iv)
main_txt_arr    = json.loads(main_txt) if is_json(main_txt) else {}
serial_main     = "admin_"+str(main_txt_arr['devcieSN']) if'devcieSN' in main_txt_arr else ""
cml_send        = int(main_txt_arr['cml_send']) if 'cml_send' in main_txt_arr else 60
wss_url         = str(main_txt_arr['wss']) if 'wss' in main_txt_arr else ""
ftp_host        = str(main_txt_arr['ftp_host']) if 'ftp_host' in main_txt_arr else ""
ftp_port        = int(main_txt_arr['ftp_port']) if 'ftp_port' in main_txt_arr else 21
ftp_u           = str(main_txt_arr['ftp_u']) if 'ftp_u' in main_txt_arr else ""
ftp_p           = str(main_txt_arr['ftp_p']) if 'ftp_p' in main_txt_arr else ""

print(main_txt_arr)

def ftp_download(ftp_path,my_path,filename):
    ftp = ftplib.FTP()
    # host = "172.16.0.65"
    # port = 2002
    host = str(ftp_host)
    port = int(ftp_port)
    timeouts = 3
    ftp.connect(host, port, timeouts)
    # print(ftp.getwelcome())
    # ftp.login("meowftp", "Asefa@2o23")
    ftp.login(str(ftp_u), str(ftp_p))
    # ftp.cwd('/zupload/'+serial_main+'/')
    ftp.cwd(ftp_path)
    # ftp.sendcmd('SITE CHMOD 777 '+file_name)

    # print(ftp.dir())
    # with open('test_001.py', 'wb') as f:
    ftp.retrbinary('RETR '+filename, open(filename, 'wb').write)
    ftp.quit()
    writefile("\n# OK",filename,'a')

def get_current():
    time_l = time.time()
    time_test = datetime.fromtimestamp(int(time_l))
    date_time = time_test.strftime("%Y-%m-%d %H:%M:%S")
    return date_time

def get_ipv4_from_nic(interface):
    import psutil
    import socket
    interface_addrs = psutil.net_if_addrs().get(interface) or []
    for snicaddr in interface_addrs:
        if snicaddr.family == socket.AF_INET:
            return snicaddr.address
        
def ftp_download(src,dst):
    try:
        ftp = ftplib.FTP()
        # host = "172.16.0.65"
        # port = 2002
        host = str(ftp_host)
        port = int(ftp_port)
        timeouts = 3
        src_fname = os.path.basename(src)
        src_path = os.path.dirname(src)
        dst_fname = os.path.basename(dst)
        # print(src_path,src_fname,dst_fname)

        ftp.connect(host, port, timeouts)
        # print(ftp.getwelcome())
        # ftp.login("meowftp", "Asefa@2o23")
        # print(str(ftp_u), str(ftp_p))
        ftp.login(str(ftp_u), str(ftp_p))

        # ftp.cwd('/dconfig/'+serial_main+'/')
        ftp.cwd(src_path)
        # ftp.sendcmd('SITE CHMOD 777 '+file_name)
        # print(ftp.dir())
        # with open('test_001.py', 'wb') as f:
        path_filename_dl = os.path.dirname(__file__)+dst
        if ftp.retrbinary('RETR '+src_fname, open(path_filename_dl, 'wb').write):
            ftp.quit()
            os.system('sudo chmod 777 '+path_filename_dl)
                
            return True
        else:
            return False
    except Exception as e:
        mlog_err = "act|{}".format(e)
        # log_error(mlog_err,"event","a")
        return False
    
def ftp_upload(src,dst):
    try:
        ftp = ftplib.FTP()
        # host = "172.16.0.65"
        # port = 2002
        host = str(ftp_host)
        port = int(ftp_port)
        timeouts = 3

        src_fname = os.path.basename(src)
        src_path = os.path.dirname(src)
        dst_fname = os.path.basename(dst)
        dst_path = os.path.dirname(dst)
        # print(src_path,src_fname)
        # print(dst_path+'==',str(dst_fname))
        # print("SRC ===="+str(src))
        ftp.connect(host, port, timeouts)
        # ftp.login("meowftp", "Asefa@2o23")
        ftp.login(str(ftp_u), str(ftp_p))

        ftp.cwd(dst_path)

        if os.path.exists(src):
            file = open(src,'rb')
            if ftp.storbinary('STOR '+dst_fname, file):
                ftp.sendcmd('SITE CHMOD 777 '+str(dst_fname))
                ftp.quit()
                return True
            else:
                return False
        else:
            return False
    except Exception as e:
        mlog_err = "act|{}".format(e)
        # log_error(mlog_err,"event","a")
        return False
    
def hh():
    # print("========")
    time_hb = time.time()

    a1 = {}
    a1["mode"] = "check_ws"
    a1["device_SN"] = serial_main
    a1["data"] = ""

    ts_e = int(time.time())
    a1["ts"] = ts_e

    diff_cmd = int(int(time.time())-int(ts_cmd))
    print("==diff time ==="+str(int(time.time()))+" - "+str(ts_cmd)+" = "+str(diff_cmd))
    print(a1)
    httpSend = requests.post("http://api.mdbiot.com/vx_mdbiot_api.php",data={"mode":"WSDevice","WSData": json.dumps(a1),"cne":g_cne},headers={"User-Agent": "INNO/2025"},verify=False,timeout=3)
    # if httpSend.status_code == 200:
    if httpSend.status_code == 200:
        print("===httpSend=="+str(httpSend.text))
        g_cne_arr = json.loads(httpSend.text) if is_json(httpSend.text) else {}
        if g_cne_arr != {}:
            ms_minus = int(g_cne_arr['ms_minus']) if 'ms_minus' in g_cne_arr else 0
            g_cne = g_cne_arr['cne'] if 'cne' in g_cne_arr else ''
            sec_send = g_cne_arr['sec_send'] if 'sec_send' in g_cne_arr else ''
            print("====================================================================")
            print("===g_cne=="+str(g_cne))
            print("===ms_minus=="+str(ms_minus))
            print("===sec_send=="+str(sec_send))
            print("====================================================================")

        
    if diff_cmd > 120 and diff_cmd != int(time.time()):
        ts_cmd = int(time.time())

# The callback for when the client receives a CONNACK response from the server.
def on_connect(client, userdata, flags, reason_code, properties):
    print(f"Connected with result code {reason_code}")
    # Subscribing in on_connect() means that if we lose the connection and
    # reconnect then subscriptions will be renewed.
    client.subscribe("meow/{}".format(serial_main))
    print("res/"+serial_main, "connect1")
    client.publish("res/"+serial_main, "connect1")
    

# The callback for when a PUBLISH message is received from the server.
def on_message(client, userdata, msg):
    global ts_cmd
    try:
        msg_arr = dict()
        message = (msg.payload).decode("utf-8")
        time_conn = get_current()
        print(str(time_conn)+'|'+(message))
        # print(msg.topic+" "+str(msg.payload))
        msg = message
        if is_json(msg):
            msg_arr = json.loads(msg)
            time_data = get_current()
            
            # writefile(msg,'cma.json','w')
            ts_e = int(time.time())
            res_cne = enc_ssl(json.dumps({"ts":ts_e}),"inno2024","")
            if msg_arr:
                if 'ts_cmd' in msg_arr:
                    print("=====",msg_arr['ts_cmd'])
                    ts_cmd = msg_arr['ts_cmd']
                    diff_cmd = int(int(time.time())-int(ts_cmd))

                    if diff_cmd > 120 and diff_cmd != int(time.time()):
                        ts_cmd = int(time.time())
                        os.system("pm2 restart all")

                if 'mode' in msg_arr: #special function()
                    # print(msg_arr['mode'],"==",msg_arr['data'])
                    msg_mode = msg_arr['mode']
                    ts_cmd = int(time.time())

                    if msg_mode == "check_ws":
                        pass
                    elif msg_mode == "cmd":
                        msg_cmdid = msg_arr['cmd_id'] if "cmd_id" in msg_arr else "C" + str(int(time.time()*1000))
                        cmd_id = msg_cmdid
                        msg_data = msg_arr['data']
                        data_output = {}
                        # print("===Output_CMD:",msg_data)
                        if "getfile" in msg_data:
                            def download(url,target):
                                get_response = requests.get(url,stream=True)
                                file_name  = url.split("/")[-1]
                                # print(os.getcwd())
                                with open(os.getcwd()+"/config/"+target, 'wb') as f:
                                    for chunk in get_response.iter_content(chunk_size=1024):
                                        if chunk: # filter out keep-alive new chunks
                                            f.write(chunk)
                                    os.system('sudo chmod 777 '+os.getcwd()+"/config/"+target)

                            path_dl = list(msg_data['getfile'].keys())[0]
                            path_tg = list(list(msg_data['getfile'].values())[0].keys())[0]
                            print("==path :",path_dl)
                            print("==Target :",path_tg)
                            download(path_dl,path_tg)
                        elif "EV" in msg_data:
                            data_output = {}
                            if "config" in msg_data['EV']:
                                if "write" in msg_data['EV']['config']:
                                    print("==path_EV",msg_data['EV']['config']['write'])
                                    cev_txt = read_file('cev.json') if os.path.exists('cev.json') else ""
                                    cev_arr = json.loads(cev_txt) if is_json(cev_txt) else {}
                                    data_output[cmd_id] = {"writeconfig":msg_data['EV']['config']}
                                    print("===Output:",data_output)
                                    writefile(json.dumps(data_output),'cev.json','w')
                                    # writefile(json.dumps(data_output),'cma2.json','w')
                                    os.system('sudo chmod 777 cev.json')
                                if "read" in msg_data['EV']['config']:
                                    print("==path_EV",msg_data['EV']['config']['read'])
                                    cev_txt = read_file('cev.json') if os.path.exists('cev.json') else ""
                                    cev_arr = json.loads(cev_txt) if is_json(cev_txt) else {}
                                    data_output[cmd_id] = {"readconfig":msg_data['EV']['config']}
                                    print("===Output:",data_output)
                                    writefile(json.dumps(data_output),'cev.json','w')
                                    # writefile(json.dumps(data_output),'cma2.json','w')
                                    os.system('sudo chmod 777 cev.json')

                        elif "VPN" in msg_data:
                            print("===VPN",msg_data['VPN'])
                            global status_vpn
                            if int(msg_data['VPN']) == 0:
                                status_vpn = 0
                                # os.system("pm2 restart all")
                                os.system("pm2 restart all")

                            if int(msg_data['VPN']) == 1:
                                # status_vpn = 1 if status_vpn == 0 else 0

                                if status_vpn == 0:
                                    status_vpn = 1
                                if status_vpn > 0:
                                    a1 = dict()
                                    a1["ipvpn"] = get_ipv4_from_nic("tun0")
                                    mqttc3 = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
                                    mqttc3.connect("mqtt.mdbiot.com", 1883, 60)
                                    mqttc3.publish("meow/"+serial_main, json.dumps(a1))
                                    # mqttc3.disconnect()
                            else:
                                a1 = dict()
                                # a1["mode"] = "reply"
                                a1["ipvpn"] = get_ipv4_from_nic("tun0")
                                mqttc3 = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
                                mqttc3.connect("mqtt.mdbiot.com", 1883, 60)
                                mqttc3.publish("meow/"+serial_main, json.dumps(a1))
                        else: # command control all

                            msg_cmdid = msg_arr['cmd_id'] if "cmd_id" in msg_arr else "C" + str(int(time.time()*1000))
                            cmd_id = msg_cmdid
                            msg_data = msg_arr['data']
                            data_output = {}
                            # print("===Read==",read_file('cma.json'))

                            cma_txt = read_file('cma.json')
                            data_output = json.loads(cma_txt) if is_json(cma_txt) else {}
                            print("===Pre read===",data_output)


                            data_output[cmd_id] = {msg_mode:msg_data}
                            # data_output = {cmd_id:{msg_mode:msg_data}}
                            print("===Output:",data_output)
                            writefile(json.dumps(data_output),'cma.json','w')
                            # writefile(json.dumps(data_output),'cma2.json','w')
                            os.system('sudo chmod 777 cma.json')
                            # os.system('sudo chmod 777 cma2.json')

                                    
                    else:
                        # if "cmd_id" in msg_arr:

                        msg_cmdid = msg_arr['cmd_id'] if "cmd_id" in msg_arr else "C" + str(int(time.time()*1000))
                        cmd_id = msg_cmdid
                        msg_data = msg_arr['data']
                        data_output = {}
                        # print("===Read==",read_file('cma.json'))

                        cma_txt = read_file('cma.json')
                        data_output = json.loads(cma_txt) if is_json(cma_txt) else {}
                        print("===Pre read===",data_output)


                        data_output[cmd_id] = {msg_mode:msg_data}
                        # data_output = {cmd_id:{msg_mode:msg_data}}
                        print("===Output:",data_output)
                        writefile(json.dumps(data_output),'cma.json','w')
                        # writefile(json.dumps(data_output),'cma2.json','w')
                        os.system('sudo chmod 777 cma.json')
                        # os.system('sudo chmod 777 cma2.json')
                    
                        
                    # if "restart" in msg_arr:
                    #     os.system('sudo reboot')
                    if msg_mode == "restart":
                        os.system('sudo reboot')
                    if msg_mode == "pm2restart":
                        os.system("pm2 restart all")
                    if msg_mode == "pip":
                        msg_data = msg_arr['data']
                        # print(msg_data)
                        # os.system("lxterminal -e sudo pip install paho-mqtt")
                        # if "sudo" in msg_data:
                        #     os.system(msg_data)
                        os.system(msg_data)
                    if msg_mode == "checkstatus":
                        a1 = dict()
                        a1["ip"] = get_ipv4_from_nic("eth0")
                        a1["ipvpn"] = get_ipv4_from_nic("tun0")

                        mqttc3 = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
                        mqttc3.connect("mqtt.mdbiot.com", 1883, 60)
                        mqttc3.publish("meow/"+serial_main, json.dumps(a1))

                    if msg_mode == "uploadfile":
                        msg_data = msg_arr['data']
                    
                        if ftp_upload(msg_data['src'],msg_data['dst']):
                            mqttc3 = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
                            mqttc3.connect("mqtt.mdbiot.com", 1883, 60)
                            mqttc3.publish("res/"+serial_main, "upload success")
                        else:
                            mqttc3 = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
                            mqttc3.connect("mqtt.mdbiot.com", 1883, 60)
                            mqttc3.publish("res/"+serial_main, "upload not found")

                    if msg_mode == "downloadfile":
                        msg_data = msg_arr['data']
                    
                        if ftp_download(msg_data['src'],msg_data['dst']):
                            mqttc3 = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
                            mqttc3.connect("mqtt.mdbiot.com", 1883, 60)
                            mqttc3.publish("res/"+serial_main, "download success")
                        else:
                            mqttc3 = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
                            mqttc3.connect("mqtt.mdbiot.com", 1883, 60)
                            mqttc3.publish("res/"+serial_main, "download not found")

                # elif 'ts_cmd' in msg_arr:
                #     print("=====",msg_arr)


                    
                    
                    
                # elif 'ts_cmd' in msg_arr:
                #     print("=====",msg_arr)
        else:
            time_data = get_current()
            print(str(time_data)+' | '+str(msg))
        
    except Exception as e:
        print("[!] Exception is {}".format(e))


def Process_01():
    try:
        mqttc = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
        mqttc.on_connect = on_connect
        mqttc.on_message = on_message
        mqttc.connect("mqtt.mdbiot.com", 1883, 60)
        mqttc.loop_forever()
        # rel.timeout(10,hh)
        # rel.signal(2, rel.abort)  # Keyboard Interrupt
        # rel.dispatch()
    except Exception as e:
        print(f'{e}')

def Process_02():
    global ts_cmd
    global g_cne 

    time_hb = 0

    while True:
        try:
            # print("==time_hb",time_hb)
            if time.time() - time_hb > 60:
                time_hb = time.time()
                a1 = {}
                a1["mode"] = "check_ws"
                a1["device_SN"] = serial_main
                a1["data"] = ""

                ts_e = int(time.time())
                a1["ts"] = ts_e
                print(a1)
                diff_cmd = int(int(time.time())-int(ts_cmd))
                print("==diff time ==="+str(int(time.time()))+" - "+str(ts_cmd)+" = "+str(diff_cmd))
                # print(a1)
                httpSend = requests.post("http://api.mdbiot.com/vx_mdbiot_api.php",data={"mode":"WSDevice","WSData": json.dumps(a1),"cne":g_cne},headers={"User-Agent": "INNO/2025"},verify=False,timeout=3)
                # if httpSend.status_code == 200:
                if httpSend.status_code == 200:
                    # print("===httpSend=="+str(httpSend.text))
                    g_cne_arr = json.loads(httpSend.text) if is_json(httpSend.text) else {}
                    if g_cne_arr != {}:
                        ms_minus = int(g_cne_arr['ms_minus']) if 'ms_minus' in g_cne_arr else 0
                        g_cne = g_cne_arr['cne'] if 'cne' in g_cne_arr else ''
                        sec_send = g_cne_arr['sec_send'] if 'sec_send' in g_cne_arr else ''
                        print("====================================================================")
                        print("===g_cne=="+str(g_cne))
                        print("===ms_minus=="+str(ms_minus))
                        print("===sec_send=="+str(sec_send))
                        print("====================================================================")

                    
                if diff_cmd > 120 and diff_cmd != int(time.time()):
                    ts_cmd = int(time.time())
                    os.system("pm2 restart all")

            # if time.time() - ts_cmd > 120:
            #     # os.system("pm2 restart all")
            #     print("pm2 restart all")
            # hh()
            # time.sleep(2)
        except Exception as e:
            print(e)



def Process_04():
    global status_vpn
    global mqttc

    import subprocess
    ts_vpn = 0
    while True:
        try:
            # print("===status_vpn==",status_vpn)
            if status_vpn == 1:
                print("connect VPN")
                if get_ipv4_from_nic("tun0") != None:
                    os.system("sudo killall openvpn")
                # /home/pi/Desktop/python/VPN/VPN
                subprocess.Popen("python3 /home/pi/ptest/zrunvpn.py", shell=True)
                # subprocess.Popen("sudo openvpn --config ~/python/VPN/VPN.ovpn", shell=True)
                status_vpn = 2
                ts_vpn = time.time()
                

            if status_vpn == 2:
                tsnow_vpn = time.time()
                if int(tsnow_vpn) - int(ts_vpn) >= 5 :
                    a1 = dict()
                    # a1["mode"] = "reply"
                    a1["ipvpn"] = get_ipv4_from_nic("tun0")

                    mqttc3 = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
                    mqttc3.connect("mqtt.mdbiot.com", 1883, 60)
                    mqttc3.publish("meow/"+serial_main, json.dumps(a1))
                    mqttc3.publish("res/"+serial_main, json.dumps(a1))
                    # mqttc3.disconnect()
                    print("Send MQTT===")
                    status_vpn = 3

                    mqttc = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
                    mqttc.on_connect = on_connect
                    mqttc.on_message = on_message
                    mqttc.connect("mqtt.mdbiot.com", 1883, 60)
                    mqttc.loop_forever()
        except Exception as e:
            pass

P1 = threading.Thread(name='Process_01', target=Process_01)
# P2 = threading.Thread(name='Process_02', target=Process_02)
P4 = threading.Thread(name='Process_04', target=Process_04)

P1.start()
# P2.start()
P4.start()

P1.join()
# P2.join()
P4.join()


